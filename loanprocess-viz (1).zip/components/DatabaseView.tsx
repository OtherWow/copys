import React from 'react';
import { SimulationState, TABLE_NAMES } from '../types';
import clsx from 'clsx';

interface DatabaseViewProps {
  state: SimulationState;
}

const TableCard = ({ title, rows }: { title: string, rows: any[] }) => (
  <div className="flex flex-col h-64 bg-slate-900 border border-slate-700 rounded-md overflow-hidden">
    <div className="px-3 py-2 bg-slate-800 border-b border-slate-700 flex justify-between items-center">
      <span className="text-xs font-mono font-bold text-slate-300 truncate mr-2" title={title}>{title}</span>
      <span className="text-[10px] bg-slate-700 px-1.5 py-0.5 rounded text-slate-400 whitespace-nowrap">{rows.length} rows</span>
    </div>
    <div className="overflow-auto p-0">
      <table className="w-full text-left text-[10px] font-mono">
        <thead className="bg-slate-800/50 text-slate-500 sticky top-0">
          <tr>
            <th className="px-2 py-1">ID</th>
            <th className="px-2 py-1">Details</th>
            <th className="px-2 py-1">Status</th>
          </tr>
        </thead>
        <tbody className="divide-y divide-slate-800">
          {rows.map((row) => (
            <tr key={row.id} className="hover:bg-slate-800/50 transition-colors">
              <td className="px-2 py-1 text-slate-500">{row.id}</td>
              <td className="px-2 py-1 text-slate-300">
                {Object.entries(row).map(([k, v]) => {
                   if (['id', 'created_at', 'status'].includes(k)) return null;
                   return <div key={k}><span className="text-slate-500">{k}:</span> {String(v)}</div>;
                })}
              </td>
              <td className="px-2 py-1">
                <span className={clsx(
                  "px-1 py-0.5 rounded",
                  row.status === 'PENDING' ? "bg-yellow-900/30 text-yellow-500" :
                  row.status === 'APPROVED' ? "bg-blue-900/30 text-blue-500" :
                  row.status === 'FINALIZED' ? "bg-purple-900/30 text-purple-500" :
                  row.status === 'SUCCESS' ? "bg-green-900/30 text-green-500" :
                  "bg-slate-700 text-slate-400"
                )}>
                  {row.status || row.accounting_status || 'OK'}
                </span>
              </td>
            </tr>
          ))}
          {rows.length === 0 && (
            <tr>
              <td colSpan={3} className="px-2 py-8 text-center text-slate-600 italic">No Data</td>
            </tr>
          )}
        </tbody>
      </table>
    </div>
  </div>
);

const DatabaseView: React.FC<DatabaseViewProps> = ({ state }) => {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4 p-4 bg-slate-950">
      {/* Entity Tables */}
      <TableCard title={TABLE_NAMES.LOAN_PACKAGE_SUMMARY} rows={state.tables[TABLE_NAMES.LOAN_PACKAGE_SUMMARY]} />
      <TableCard title={TABLE_NAMES.LOAN_SUMMARY} rows={state.tables[TABLE_NAMES.LOAN_SUMMARY]} />
      <TableCard title={TABLE_NAMES.LOAN_PAYMENT_RULE} rows={state.tables[TABLE_NAMES.LOAN_PAYMENT_RULE]} />
      
      {/* Request Tables */}
      <TableCard title={TABLE_NAMES.LOAN_DRAW_REQUEST} rows={state.tables[TABLE_NAMES.LOAN_DRAW_REQUEST]} />
      <TableCard title={TABLE_NAMES.LOAN_PAYMENT_REQUEST} rows={state.tables[TABLE_NAMES.LOAN_PAYMENT_REQUEST]} />
      
      {/* Queues */}
      <TableCard title={TABLE_NAMES.LOAN_TRANS_QUEUE} rows={state.tables[TABLE_NAMES.LOAN_TRANS_QUEUE]} />
      <TableCard title={TABLE_NAMES.LOAN_TRANS_FINAL_QUEUE} rows={state.tables[TABLE_NAMES.LOAN_TRANS_FINAL_QUEUE]} />
      
      {/* External/Downstream */}
      <TableCard title={TABLE_NAMES.ACCOUNTING_REQ} rows={state.tables[TABLE_NAMES.ACCOUNTING_REQ]} />
      <TableCard title={TABLE_NAMES.NACHA_TRANS} rows={state.tables[TABLE_NAMES.NACHA_TRANS]} />
      <TableCard title={TABLE_NAMES.WIRE_TRANS} rows={state.tables[TABLE_NAMES.WIRE_TRANS]} />
      <TableCard title={TABLE_NAMES.LOAN_BILL} rows={state.tables[TABLE_NAMES.LOAN_BILL]} />
    </div>
  );
};

export default DatabaseView;