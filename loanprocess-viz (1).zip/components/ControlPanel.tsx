
import React from 'react';
import { Play, DollarSign, RotateCcw, Zap, RefreshCw, Layers, Pause } from 'lucide-react';

interface ControlPanelProps {
  actions: {
    createLine: () => void;
    performDraw: (type: 'VARIABLE' | 'FIXED_TERM', amount: number) => void;
    performOneTimePayment: () => void;
    performRollover: () => void;
    performCapAndRoll: () => void;
    resetSimulation: () => void;
    togglePause: () => void;
  };
  isProcessing: boolean;
  isPaused: boolean;
}

const ControlPanel: React.FC<ControlPanelProps> = ({ actions, isProcessing, isPaused }) => {
  return (
    <div className="sticky top-0 z-50 flex flex-wrap gap-2 p-3 bg-slate-800 border-b border-slate-700 shadow-md items-center">
      <h2 className="text-xs font-bold text-slate-500 uppercase tracking-wider mr-2 hidden md:block">SCENARIOS</h2>

      <button
        onClick={actions.createLine}
        disabled={isProcessing}
        className="flex items-center gap-2 px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white rounded text-xs font-medium transition-colors"
      >
        <Play className="w-3 h-3" /> Create Line
      </button>

      <button
        onClick={() => actions.performDraw('VARIABLE', 5000)}
        disabled={isProcessing}
        className="flex items-center gap-2 px-3 py-1.5 bg-blue-600 hover:bg-blue-500 disabled:opacity-50 text-white rounded text-xs font-medium transition-colors"
      >
        <DollarSign className="w-3 h-3" /> Var Draw
      </button>

      <button
        onClick={() => actions.performDraw('FIXED_TERM', 50000)}
        disabled={isProcessing}
        className="flex items-center gap-2 px-3 py-1.5 bg-cyan-600 hover:bg-cyan-500 disabled:opacity-50 text-white rounded text-xs font-medium transition-colors"
      >
        <DollarSign className="w-3 h-3" /> Fixed Draw
      </button>

      <div className="h-6 w-px bg-slate-600 mx-1"></div>

      <button
        onClick={actions.performOneTimePayment}
        disabled={isProcessing}
        className="flex items-center gap-2 px-3 py-1.5 bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 text-white rounded text-xs font-medium transition-colors"
      >
        <Zap className="w-3 h-3" /> One-Time Pay
      </button>

      <div className="h-6 w-px bg-slate-600 mx-1"></div>

      <button
        onClick={actions.performRollover}
        disabled={isProcessing}
        className="flex items-center gap-2 px-3 py-1.5 bg-orange-600 hover:bg-orange-500 disabled:opacity-50 text-white rounded text-xs font-medium transition-colors"
      >
        <RefreshCw className="w-3 h-3" /> Rollover
      </button>

      <button
        onClick={actions.performCapAndRoll}
        disabled={isProcessing}
        className="flex items-center gap-2 px-3 py-1.5 bg-purple-600 hover:bg-purple-500 disabled:opacity-50 text-white rounded text-xs font-medium transition-colors"
      >
        <Layers className="w-3 h-3" /> Cap & Roll
      </button>

      <div className="flex-1"></div>

      {/* Pause/Resume Button */}
      <button
        onClick={actions.togglePause}
        className={`flex items-center gap-2 px-4 py-1.5 rounded text-xs font-bold transition-all border ${
          isPaused 
            ? 'bg-yellow-500 text-slate-900 hover:bg-yellow-400 border-yellow-400 animate-pulse' 
            : 'bg-slate-700 text-slate-300 hover:bg-slate-600 border-slate-600'
        }`}
      >
        {isPaused ? <Play className="w-3 h-3 fill-current" /> : <Pause className="w-3 h-3 fill-current" />}
        {isPaused ? 'RESUME' : 'PAUSE'}
      </button>

      <button
        onClick={actions.resetSimulation}
        disabled={isProcessing && !isPaused}
        className="flex items-center gap-2 px-3 py-1.5 bg-slate-700 hover:bg-slate-600 text-slate-300 border border-slate-600 rounded text-xs font-medium transition-colors"
      >
        <RotateCcw className="w-3 h-3" /> Reset
      </button>
    </div>
  );
};

export default ControlPanel;
