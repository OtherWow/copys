
import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Database, User, Server, Globe, Activity, Cpu } from 'lucide-react';
import { NodeConfig, NodeType, DataPacket } from '../types';
import { NODES, GRID_COLS, GRID_ROWS, CONNECTIONS } from '../constants';
import clsx from 'clsx';

interface FlowMapProps {
  activePackets: DataPacket[];
}

const NodeIcon = ({ type, label }: { type: NodeType, label: string }) => {
  const iconClass = "w-7 h-7"; // Increased size
  
  // Special handling for Non-Database types
  if (type === NodeType.USER) return <User className={`${iconClass} text-white`} />;
  if (type === NodeType.PROCESS) return <Cpu className={`${iconClass} text-amber-200`} />;
  if (type === NodeType.EXTERNAL) {
     if (label.includes('Bank')) return <Globe className={`${iconClass} text-cyan-200`} />;
     return <Server className={`${iconClass} text-red-200`} />;
  }
  
  // Unified Database Icon for all tables
  return <Database className={`${iconClass} text-blue-200`} />;
};

const FlowMap: React.FC<FlowMapProps> = ({ activePackets }) => {
  
  const getNodeCenter = (node: NodeConfig) => {
    // Adjusted logic to account for the padding added to the grid container
    // This ensures lines match the visually compressed grid
    // We map 0..COLS to 10%..90% to pull them closer
    const xPadding = 10; // %
    const yPadding = 10; // %
    const effectiveWidth = 100 - (xPadding * 2);
    const effectiveHeight = 100 - (yPadding * 2);

    const x = xPadding + ((node.col + 0.5) / GRID_COLS) * effectiveWidth;
    const y = yPadding + ((node.row + 0.5) / GRID_ROWS) * effectiveHeight;
    return { x, y };
  };

  const getNodePositionStyle = (id: string) => {
    const node = NODES.find(n => n.id === id);
    if (!node) return { top: '50%', left: '50%' };
    const pos = getNodeCenter(node);
    return { 
      top: `${pos.y}%`, 
      left: `${pos.x}%` 
    };
  };

  return (
    <div className="relative w-full h-full border border-slate-800/50 rounded-3xl bg-slate-900/40 backdrop-blur-sm shadow-2xl overflow-visible">
      
      {/* 1. SVG Layer for Lines */}
      <svg className="absolute inset-0 w-full h-full pointer-events-none z-0">
        <defs>
          <marker
            id="arrowhead"
            markerWidth="8"
            markerHeight="6"
            refX="8"
            refY="3"
            orient="auto"
          >
            <polygon points="0 0, 8 3, 0 6" fill="#475569" />
          </marker>
        </defs>
        {CONNECTIONS.map((conn, idx) => {
          const startNode = NODES.find(n => n.id === conn.from);
          const endNode = NODES.find(n => n.id === conn.to);
          if (!startNode || !endNode) return null;

          const start = getNodeCenter(startNode);
          const end = getNodeCenter(endNode);

          return (
            <g key={idx}>
              <line
                x1={`${start.x}%`}
                y1={`${start.y}%`}
                x2={`${end.x}%`}
                y2={`${end.y}%`}
                stroke="#0f172a"
                strokeWidth="4"
              />
              <line
                x1={`${start.x}%`}
                y1={`${start.y}%`}
                x2={`${end.x}%`}
                y2={`${end.y}%`}
                stroke="#334155"
                strokeWidth="1.5"
                strokeDasharray="4,4"
                markerEnd="url(#arrowhead)"
                opacity="0.5"
              />
            </g>
          );
        })}
      </svg>

      {/* 2. Nodes Grid */}
      {/* Added padding (p-[10%]) to bring nodes closer together visually within the container */}
      <div 
        className="absolute inset-0 grid gap-4 pointer-events-none z-10"
        style={{
          padding: '5% 10%', // Squeeze horizontal axis more to bring them closer
          gridTemplateColumns: `repeat(${GRID_COLS}, 1fr)`,
          gridTemplateRows: `repeat(${GRID_ROWS}, 1fr)`
        }}
      >
        {NODES.map((node) => {
          const isActive = activePackets.some(p => p.to === node.id || p.from === node.id);
          
          return (
            <div 
              key={node.id} 
              className="relative pointer-events-auto flex items-center justify-center"
              style={{ gridColumnStart: node.col + 1, gridRowStart: node.row + 1 }}
            >
              <div className={clsx(
                "relative flex flex-col items-center justify-center w-full max-w-[110px] aspect-square rounded-xl border transition-all duration-500",
                "shadow-[0_0_10px_rgba(0,0,0,0.3)] backdrop-blur-md",
                isActive ? "scale-105 border-sky-500/50 shadow-[0_0_15px_rgba(14,165,233,0.3)]" : "border-slate-700/50 bg-slate-800/60",
                node.type === NodeType.USER ? "bg-indigo-900/30" :
                node.type === NodeType.EXTERNAL ? "bg-red-900/10" :
                ""
              )}>
                {isActive && (
                  <span className="absolute inset-0 rounded-xl animate-ping border border-sky-400/30 opacity-75 pointer-events-none"></span>
                )}

                <div className={clsx(
                  "mb-2 p-2 rounded-lg transition-colors duration-500",
                  isActive ? "bg-slate-700" : "bg-slate-800",
                  node.type === NodeType.USER ? "text-indigo-400" :
                  node.type === NodeType.DB_TABLE ? "text-blue-400" :
                  node.type === NodeType.PROCESS ? "text-amber-400" :
                  "text-red-400"
                )}>
                  <NodeIcon type={node.type} label={node.label} />
                </div>
                
                <span className="text-[10px] font-bold font-mono text-center text-slate-300 leading-tight w-full px-1 break-words tracking-tight">
                  {node.label}
                </span>
              </div>
            </div>
          );
        })}
      </div>

      {/* 3. Packets Animation with Phantom Trail */}
      <div className="absolute inset-0 pointer-events-none z-20">
        <AnimatePresence>
          {activePackets.map((packet) => {
            const start = getNodePositionStyle(packet.from);
            const end = getNodePositionStyle(packet.to);
            const duration = (packet.duration || 2800) / 1000;

            return (
              <React.Fragment key={packet.id}>
                {/* Main Packet */}
                <motion.div
                  initial={{ top: start.top, left: start.left, opacity: 0, scale: 0.5 }}
                  animate={{ 
                    top: end.top, 
                    left: end.left, 
                    opacity: 1, 
                    scale: 1,
                    transition: { duration: duration, ease: "easeInOut" } 
                  }}
                  exit={{ opacity: 0, scale: 0 }}
                  className="absolute flex items-center justify-center w-0 h-0"
                >
                  <div className="relative flex items-center justify-center -translate-x-1/2 -translate-y-1/2">
                    <div className={clsx(
                      "w-4 h-4 rounded-full shadow-[0_0_15px_rgba(255,255,255,0.6)] z-10 border-2 border-white", 
                      packet.color
                    )}></div>
                    <div className={clsx("absolute w-8 h-8 rounded-full opacity-30 animate-ping", packet.color)}></div>
                    <div className="absolute -top-6 whitespace-nowrap bg-slate-900/90 px-2 py-0.5 rounded text-white font-mono text-[10px] border border-slate-700 shadow-xl z-20">
                      {packet.label}
                    </div>
                  </div>
                </motion.div>

                {/* Phantom 1 */}
                <motion.div
                  initial={{ top: start.top, left: start.left, opacity: 0 }}
                  animate={{ 
                    top: end.top, 
                    left: end.left, 
                    opacity: [0, 0.6, 0], 
                    scale: 0.8,
                    transition: { duration: duration, ease: "easeInOut", delay: 0.1 } 
                  }}
                  className="absolute flex items-center justify-center w-0 h-0"
                >
                  <div className={clsx("w-3 h-3 rounded-full opacity-50 -translate-x-1/2 -translate-y-1/2", packet.color)}></div>
                </motion.div>

                 {/* Phantom 2 */}
                 <motion.div
                  initial={{ top: start.top, left: start.left, opacity: 0 }}
                  animate={{ 
                    top: end.top, 
                    left: end.left, 
                    opacity: [0, 0.4, 0], 
                    scale: 0.6,
                    transition: { duration: duration, ease: "easeInOut", delay: 0.2 } 
                  }}
                  className="absolute flex items-center justify-center w-0 h-0"
                >
                  <div className={clsx("w-2 h-2 rounded-full opacity-30 -translate-x-1/2 -translate-y-1/2", packet.color)}></div>
                </motion.div>
              </React.Fragment>
            );
          })}
        </AnimatePresence>
      </div>
      
    </div>
  );
};

export default FlowMap;
