import React, { useEffect, useRef } from 'react';
import { LogEntry } from '../types';
import clsx from 'clsx';
import { Terminal } from 'lucide-react';

const LogConsole: React.FC<{ logs: LogEntry[] }> = ({ logs }) => {
  return (
    <div className="flex flex-col h-full bg-slate-900 border-l border-slate-700 w-80">
      <div className="p-3 border-b border-slate-700 flex items-center gap-2 bg-slate-800">
        <Terminal className="w-4 h-4 text-slate-400" />
        <h3 className="text-xs font-bold text-slate-300 uppercase">System Logs</h3>
      </div>
      <div className="flex-1 overflow-y-auto p-2 space-y-2">
        {logs.map((log) => (
          <div key={log.id} className="text-[11px] font-mono border-l-2 pl-2 py-1 border-slate-700">
            <span className="text-slate-500 mr-2">[{log.timestamp}]</span>
            <span className={clsx(
              log.type === 'error' ? 'text-red-400' :
              log.type === 'success' ? 'text-emerald-400' :
              log.type === 'process' ? 'text-yellow-400' :
              'text-blue-300'
            )}>
              {log.message}
            </span>
          </div>
        ))}
        {logs.length === 0 && <div className="text-slate-600 text-xs p-2 italic">Ready to start...</div>}
      </div>
    </div>
  );
};

export default LogConsole;