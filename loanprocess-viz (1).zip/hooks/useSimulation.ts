
import { useState, useCallback, useRef } from 'react';
import { SimulationState, TABLE_NAMES, DataPacket, LogEntry, TableRow } from '../types';
import { v4 as uuidv4 } from 'uuid';

const INITIAL_STATE: SimulationState = {
  tables: Object.values(TABLE_NAMES).reduce((acc, name) => ({ ...acc, [name]: [] }), {} as Record<string, TableRow[]>),
  logs: [],
  isProcessing: false,
};

export const useSimulation = () => {
  const [state, setState] = useState<SimulationState>(INITIAL_STATE);
  const [activePackets, setActivePackets] = useState<DataPacket[]>([]);
  const [isPaused, setIsPaused] = useState(false);
  
  // Refs to access fresh state inside async closures
  const stateRef = useRef(state);
  stateRef.current = state;
  const isPausedRef = useRef(isPaused);
  isPausedRef.current = isPaused;
  const pauseResolverRef = useRef<(() => void) | null>(null);

  const togglePause = useCallback(() => {
    if (isPausedRef.current) {
      // Resume
      setIsPaused(false);
      if (pauseResolverRef.current) {
        pauseResolverRef.current();
        pauseResolverRef.current = null;
      }
    } else {
      // Pause
      setIsPaused(true);
    }
  }, []);

  const waitIfPaused = async () => {
    if (isPausedRef.current) {
      await new Promise<void>(resolve => {
        pauseResolverRef.current = resolve;
      });
    }
  };

  const resetSimulation = () => {
    setState(INITIAL_STATE);
    setActivePackets([]);
    setIsPaused(false);
    if (pauseResolverRef.current) pauseResolverRef.current();
  };

  const insertRecord = (tableName: string, record: any) => {
    const newRow = { id: uuidv4().slice(0, 8), ...record, created_at: new Date().toISOString() };
    setState(prev => ({
      ...prev,
      tables: {
        ...prev.tables,
        [tableName]: [newRow, ...prev.tables[tableName]],
      },
    }));
    return newRow;
  };

  const updateRecord = (tableName: string, recordId: string, updates: any) => {
     setState(prev => ({
      ...prev,
      tables: {
        ...prev.tables,
        [tableName]: prev.tables[tableName].map(row => row.id === recordId ? { ...row, ...updates } : row),
      },
    }));
  };

  const sendPacket = async (from: string, to: string, label: string, color: string = 'bg-blue-500', duration: number = 2800) => {
    // 1. Wait if paused BEFORE starting
    await waitIfPaused();

    const id = uuidv4();
    setActivePackets(prev => [...prev, { id, from, to, label, color, duration }]);
    
    // 2. Wait for animation duration (let it fly)
    await new Promise(resolve => setTimeout(resolve, duration));

    // 3. Wait if paused AFTER animation (Packet freezes at destination)
    await waitIfPaused();

    // 4. Remove packet
    setActivePackets(prev => prev.filter(p => p.id !== id));
    
    // 5. Small buffer between steps
    await new Promise(resolve => setTimeout(resolve, 200));
  };

  // --- SCENARIO 1: Create Line ---
  const createLine = async () => {
    if (state.isProcessing) return;
    setState(prev => ({ ...prev, isProcessing: true }));

    await sendPacket('user', TABLE_NAMES.LOAN_PACKAGE_SUMMARY, '创建 Line', 'bg-green-500');
    const pkg = insertRecord(TABLE_NAMES.LOAN_PACKAGE_SUMMARY, { 
      client_name: 'Acme Corp', 
      credit_limit: 1000000, 
      status: 'ACTIVE' 
    });

    await sendPacket(TABLE_NAMES.LOAN_PACKAGE_SUMMARY, TABLE_NAMES.LOAN_SUMMARY, '初始化 Variable Loan', 'bg-green-500');
    insertRecord(TABLE_NAMES.LOAN_SUMMARY, {
      package_id: pkg.id,
      loan_type: 'VARIABLE',
      balance: 0,
      status: 'OPEN'
    });

    setState(prev => ({ ...prev, isProcessing: false }));
  };

  // --- SCENARIO 2: Draw ---
  const performDraw = async (type: 'VARIABLE' | 'FIXED_TERM', amount: number) => {
    if (state.isProcessing) return;
    setState(prev => ({ ...prev, isProcessing: true }));
    const color = 'bg-blue-500';

    await sendPacket('user', TABLE_NAMES.LOAN_DRAW_REQUEST, '发起 Draw 请求', color);
    const drawReq = insertRecord(TABLE_NAMES.LOAN_DRAW_REQUEST, {
      amount,
      draw_type: type === 'VARIABLE' ? 'ACH' : 'WIRE',
      status: 'PENDING'
    });

    // Processing delay (can be paused)
    await new Promise(r => setTimeout(r, 800));
    await waitIfPaused();
    
    updateRecord(TABLE_NAMES.LOAN_DRAW_REQUEST, drawReq.id, { status: 'APPROVED' });

    if (type === 'FIXED_TERM') {
      await sendPacket(TABLE_NAMES.LOAN_DRAW_REQUEST, TABLE_NAMES.LOAN_SUMMARY, '创建 Fixed Loan', 'bg-yellow-500');
      insertRecord(TABLE_NAMES.LOAN_SUMMARY, {
        loan_type: 'FIXED',
        balance: amount,
        term: '30_DAYS',
        status: 'OPEN'
      });
    }

    await sendPacket(TABLE_NAMES.LOAN_DRAW_REQUEST, TABLE_NAMES.LOAN_TRANS_QUEUE, '写入交易队列', color);
    const transQ = insertRecord(TABLE_NAMES.LOAN_TRANS_QUEUE, {
      source_id: drawReq.id,
      source_table: 'loan_draw_request',
      amount,
      status: 'PENDING'
    });

    await sendPacket(TABLE_NAMES.LOAN_TRANS_QUEUE, TABLE_NAMES.LOAN_TRANS_FINAL_QUEUE, '最终交易确认', 'bg-purple-500');
    updateRecord(TABLE_NAMES.LOAN_TRANS_QUEUE, transQ.id, { status: 'FINALIZED' });
    const finalQ = insertRecord(TABLE_NAMES.LOAN_TRANS_FINAL_QUEUE, {
      original_id: transQ.id,
      amount,
      accounting_status: 'INIT'
    });

    await processDownstream(finalQ, type === 'VARIABLE' ? 'ACH' : 'WIRE');

    setState(prev => ({ ...prev, isProcessing: false }));
  };

  // --- SCENARIO 3: One-time Payment ---
  const performOneTimePayment = async () => {
    if (state.isProcessing) return;
    setState(prev => ({ ...prev, isProcessing: true }));
    const color = 'bg-indigo-500';

    await sendPacket('user', TABLE_NAMES.LOAN_PAYMENT_REQUEST, 'Post Payment', color);
    const payReq = insertRecord(TABLE_NAMES.LOAN_PAYMENT_REQUEST, {
      amount: 2000,
      type: 'ONE_TIME',
      status: 'PENDING'
    });
    
    await new Promise(r => setTimeout(r, 500));
    await waitIfPaused();
    
    updateRecord(TABLE_NAMES.LOAN_PAYMENT_REQUEST, payReq.id, { status: 'APPROVED' });

    await sendPacket(TABLE_NAMES.LOAN_PAYMENT_REQUEST, TABLE_NAMES.LOAN_TRANS_QUEUE, '写入交易队列', color);
    const transQ = insertRecord(TABLE_NAMES.LOAN_TRANS_QUEUE, {
      source_id: payReq.id,
      amount: 2000,
      status: 'PENDING'
    });

    await sendPacket(TABLE_NAMES.LOAN_TRANS_QUEUE, TABLE_NAMES.LOAN_TRANS_FINAL_QUEUE, '最终交易确认', 'bg-purple-500');
    updateRecord(TABLE_NAMES.LOAN_TRANS_QUEUE, transQ.id, { status: 'FINALIZED' });
    const finalQ = insertRecord(TABLE_NAMES.LOAN_TRANS_FINAL_QUEUE, {
      original_id: transQ.id,
      amount: 2000,
      accounting_status: 'INIT'
    });

    await processDownstream(finalQ, 'ACH');
    setState(prev => ({ ...prev, isProcessing: false }));
  };

  // --- SCENARIO 4: Rollover ---
  const performRollover = async () => {
    if (state.isProcessing) return;
    setState(prev => ({ ...prev, isProcessing: true }));
    const color = 'bg-orange-500';

    if (stateRef.current.tables[TABLE_NAMES.LOAN_BILL].length === 0) {
      insertRecord(TABLE_NAMES.LOAN_BILL, { amount_due: 50000, type: 'MATURITY_BILL' });
    }

    await sendPacket(TABLE_NAMES.LOAN_BILL, TABLE_NAMES.ROLLOVER_SUMMARY, '触发 Rollover', color);
    await sendPacket(TABLE_NAMES.LOAN_SUMMARY, TABLE_NAMES.ROLLOVER_SUMMARY, '读取 Loan 信息', color, 1500);
    
    const rollSummary = insertRecord(TABLE_NAMES.ROLLOVER_SUMMARY, {
      loan_id: 'FIXED_01',
      action: 'ROLLOVER_TO_OTHER_LOAN',
      status: 'TODO'
    });

    await new Promise(r => setTimeout(r, 800));
    await waitIfPaused();

    await sendPacket(TABLE_NAMES.ROLLOVER_SUMMARY, TABLE_NAMES.LOAN_CAP_AND_ROLL, '生成 Cap&Roll', color);
    const capRoll = insertRecord(TABLE_NAMES.LOAN_CAP_AND_ROLL, {
      source_loan: 'FIXED_01',
      target_loan: 'VAR_01',
      amount: 50000,
      status: 'PROCESSING'
    });

    await sendPacket(TABLE_NAMES.ROLLOVER_SUMMARY, TABLE_NAMES.ACCOUNTING_REQ, '关闭 Fixed Loan', 'bg-red-500');
    insertRecord(TABLE_NAMES.ACCOUNTING_REQ, { type: 'CLOSE_LOAN', status: 'PENDING' });

    await sendPacket(TABLE_NAMES.LOAN_CAP_AND_ROLL, TABLE_NAMES.LOAN_TRANS_FINAL_QUEUE, '写入 Final Queue', 'bg-purple-500');
    insertRecord(TABLE_NAMES.LOAN_TRANS_FINAL_QUEUE, {
      type: 'ROLLOVER_TRANSFER',
      amount: 50000
    });

    setState(prev => ({ ...prev, isProcessing: false }));
  };

  // --- SCENARIO 5: Cap & Roll ---
  const performCapAndRoll = async () => {
    if (state.isProcessing) return;
    setState(prev => ({ ...prev, isProcessing: true }));
    const color = 'bg-purple-400';

    await sendPacket(TABLE_NAMES.LOAN_BILL, TABLE_NAMES.LOAN_CAP_AND_ROLL, '触发逾期资本化', color);
    const capRoll = insertRecord(TABLE_NAMES.LOAN_CAP_AND_ROLL, {
      type: 'INTEREST_CAP',
      amount: 500, 
      status: 'PROCESSING'
    });

    await sendPacket(TABLE_NAMES.LOAN_CAP_AND_ROLL, TABLE_NAMES.LOAN_TRANS_FINAL_QUEUE, 'Draw From Var', color);
    insertRecord(TABLE_NAMES.LOAN_TRANS_FINAL_QUEUE, { type: 'DRAW_FROM_VAR', amount: 500 });
    
    await sendPacket(TABLE_NAMES.LOAN_CAP_AND_ROLL, TABLE_NAMES.LOAN_TRANS_FINAL_QUEUE, 'Pay To Fixed', color);
    insertRecord(TABLE_NAMES.LOAN_TRANS_FINAL_QUEUE, { type: 'PAY_TO_FIXED', amount: 500 });

    await sendPacket(TABLE_NAMES.LOAN_CAP_AND_ROLL, TABLE_NAMES.ACCOUNTING_REQ, '记账请求', 'bg-red-500');
    
    setState(prev => ({ ...prev, isProcessing: false }));
  };

  const processDownstream = async (finalQRow: any, method: 'ACH' | 'WIRE') => {
    // We don't await the whole chain to allow parallel visual flows? 
    // No, for the sake of clear "Step by Step", let's await them or at least the start.
    // For visual clarity, sequential is often better.

    // 1. Accounting
    await sendPacket(TABLE_NAMES.LOAN_TRANS_FINAL_QUEUE, TABLE_NAMES.ACCOUNTING_REQ, '请求记账', 'bg-orange-500');
    const accReq = insertRecord(TABLE_NAMES.ACCOUNTING_REQ, {
      trans_id: finalQRow.id,
      status: 'PENDING'
    });
    updateRecord(TABLE_NAMES.LOAN_TRANS_FINAL_QUEUE, finalQRow.id, { accounting_status: 'PREPARE_SYNC' });
    
    await sendPacket(TABLE_NAMES.ACCOUNTING_REQ, 'external_fis', '调用 FIS', 'bg-red-500');
    updateRecord(TABLE_NAMES.ACCOUNTING_REQ, accReq.id, { status: 'SUCCESS' });
    
    // FIS Feedback (Parallel start)
    const feedbackColor = 'bg-emerald-600';
    // We launch these without awaiting strictly to speed up tail end? 
    // Or we keep them sequential for pause support. Sequential is safer for pausing.
    await sendPacket('external_fis', TABLE_NAMES.LOAN_BILL, '更新 Bill', feedbackColor, 2000);
    insertRecord(TABLE_NAMES.LOAN_BILL, { amount: 500, due_date: '2023-12-30' });

    await sendPacket('external_fis', TABLE_NAMES.LOAN_TRANSACTION, '回写交易', feedbackColor, 2000);
    insertRecord(TABLE_NAMES.LOAN_TRANSACTION, { trans_id: finalQRow.id, status: 'POSTED' });

    await sendPacket('external_fis', TABLE_NAMES.LOAN_SUMMARY, '更新余额', feedbackColor, 2000);

    // 2. Bank
    if (method === 'ACH') {
      await sendPacket(TABLE_NAMES.LOAN_TRANS_FINAL_QUEUE, TABLE_NAMES.NACHA_TRANS, '生成 NACHA', 'bg-cyan-500');
      const nacha = insertRecord(TABLE_NAMES.NACHA_TRANS, { trans_id: finalQRow.id, status: 'GENERATED' });
      
      await sendPacket(TABLE_NAMES.NACHA_TRANS, 'external_bank', '上传银行 (ACH)', 'bg-cyan-500');
      await sendPacket('external_bank', TABLE_NAMES.NACHA_TRANS, '回写 (Completed)', 'bg-slate-400', 2000);
      updateRecord(TABLE_NAMES.NACHA_TRANS, nacha.id, { status: 'COMPLETED' });
    } else {
      await sendPacket(TABLE_NAMES.LOAN_TRANS_FINAL_QUEUE, TABLE_NAMES.WIRE_TRANS, '生成 Wire', 'bg-cyan-500');
      const wire = insertRecord(TABLE_NAMES.WIRE_TRANS, { trans_id: finalQRow.id, status: 'GENERATED' });

      await sendPacket(TABLE_NAMES.WIRE_TRANS, 'external_bank', '发送 Wire', 'bg-cyan-500');
      await sendPacket('external_bank', TABLE_NAMES.WIRE_TRANS, '回写 (Sent)', 'bg-slate-400', 2000);
      updateRecord(TABLE_NAMES.WIRE_TRANS, wire.id, { status: 'SENT' });
    }
  };

  return {
    state,
    activePackets,
    actions: {
      createLine,
      performDraw,
      performOneTimePayment,
      performRollover,
      performCapAndRoll,
      resetSimulation,
      togglePause
    },
    isPaused
  };
};
