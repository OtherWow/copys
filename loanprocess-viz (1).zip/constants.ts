
import { NodeType, NodeConfig, TABLE_NAMES } from './types';

export const NODES: NodeConfig[] = [
  // --- Row 0: Entities (The "Truth") ---
  { id: 'user', label: 'User / Admin', type: NodeType.USER, row: 0, col: 0 },
  { id: TABLE_NAMES.LOAN_PACKAGE_SUMMARY, label: 'loan_package_summary', type: NodeType.DB_TABLE, row: 0, col: 2 },
  { id: TABLE_NAMES.LOAN_SUMMARY, label: 'loan_summary', type: NodeType.DB_TABLE, row: 0, col: 3 },
  { id: TABLE_NAMES.LOAN_PAYMENT_RULE, label: 'loan_payment_rule', type: NodeType.DB_TABLE, row: 0, col: 4 },

  // --- Row 1: Requests & Summaries ---
  { id: TABLE_NAMES.LOAN_DRAW_REQUEST, label: 'loan_draw_request', type: NodeType.DB_TABLE, row: 1, col: 1 },
  { id: TABLE_NAMES.LOAN_PAYMENT_REQUEST, label: 'loan_payment_request', type: NodeType.DB_TABLE, row: 1, col: 3 },
  { id: TABLE_NAMES.LOAN_CAP_AND_ROLL, label: 'loan_cap_and_roll', type: NodeType.DB_TABLE, row: 1, col: 4 },
  { id: TABLE_NAMES.ROLLOVER_SUMMARY, label: 'rollover_summary', type: NodeType.DB_TABLE, row: 1, col: 5 },

  // --- Row 2: Queue Processing ---
  { id: TABLE_NAMES.LOAN_TRANS_QUEUE, label: 'loan_transaction_queue', type: NodeType.DB_TABLE, row: 2, col: 2 },
  { id: 'job_queue_processor', label: 'Queue Processor', type: NodeType.PROCESS, row: 2, col: 3 }, // Visual Helper
  { id: TABLE_NAMES.LOAN_TRANS_FINAL_QUEUE, label: 'loan_transaction_final_queue', type: NodeType.DB_TABLE, row: 2, col: 4 },

  // --- Row 3: Downstream Connectors ---
  { id: TABLE_NAMES.NACHA_TRANS, label: 'nacha_transaction', type: NodeType.DB_TABLE, row: 3, col: 1 },
  { id: TABLE_NAMES.ACCOUNTING_REQ, label: 'accounting_request', type: NodeType.DB_TABLE, row: 3, col: 3 },
  { id: TABLE_NAMES.WIRE_TRANS, label: 'wire_transaction', type: NodeType.DB_TABLE, row: 3, col: 5 },

  // --- Row 4: External Systems & Feedback ---
  { id: 'external_bank', label: 'Bank (ACH/Wire)', type: NodeType.EXTERNAL, row: 4, col: 1 },
  { id: 'external_fis', label: 'FIS System (GL)', type: NodeType.EXTERNAL, row: 4, col: 3 },
  { id: TABLE_NAMES.LOAN_BILL, label: 'loan_bill', type: NodeType.DB_TABLE, row: 4, col: 4 },
  { id: TABLE_NAMES.LOAN_TRANSACTION, label: 'loan_transaction', type: NodeType.DB_TABLE, row: 4, col: 5 },
];

export const CONNECTIONS = [
  // === Creation Flows ===
  { from: 'user', to: TABLE_NAMES.LOAN_PACKAGE_SUMMARY },
  { from: TABLE_NAMES.LOAN_PACKAGE_SUMMARY, to: TABLE_NAMES.LOAN_SUMMARY },
  { from: 'user', to: TABLE_NAMES.LOAN_DRAW_REQUEST },
  { from: 'user', to: TABLE_NAMES.LOAN_PAYMENT_RULE },
  { from: 'user', to: TABLE_NAMES.LOAN_PAYMENT_REQUEST }, // Onetime Payment

  // === Draw Flow ===
  { from: TABLE_NAMES.LOAN_DRAW_REQUEST, to: TABLE_NAMES.LOAN_SUMMARY }, // Fixed Draw creates loan before queue
  { from: TABLE_NAMES.LOAN_DRAW_REQUEST, to: TABLE_NAMES.LOAN_TRANS_QUEUE },

  // === Payment Flow ===
  { from: TABLE_NAMES.LOAN_PAYMENT_RULE, to: TABLE_NAMES.LOAN_PAYMENT_REQUEST },
  { from: TABLE_NAMES.LOAN_PAYMENT_REQUEST, to: TABLE_NAMES.LOAN_TRANS_QUEUE },

  // === Queue Processing ===
  { from: TABLE_NAMES.LOAN_TRANS_QUEUE, to: TABLE_NAMES.LOAN_TRANS_FINAL_QUEUE },

  // === Downstream Channels ===
  { from: TABLE_NAMES.LOAN_TRANS_FINAL_QUEUE, to: TABLE_NAMES.ACCOUNTING_REQ },
  { from: TABLE_NAMES.LOAN_TRANS_FINAL_QUEUE, to: TABLE_NAMES.NACHA_TRANS },
  { from: TABLE_NAMES.LOAN_TRANS_FINAL_QUEUE, to: TABLE_NAMES.WIRE_TRANS },

  // === External Systems ===
  { from: TABLE_NAMES.ACCOUNTING_REQ, to: 'external_fis' },
  { from: TABLE_NAMES.NACHA_TRANS, to: 'external_bank' },
  { from: TABLE_NAMES.WIRE_TRANS, to: 'external_bank' },

  // === FIS Feedback Loops ===
  { from: 'external_fis', to: TABLE_NAMES.LOAN_BILL },
  { from: 'external_fis', to: TABLE_NAMES.LOAN_TRANSACTION },
  { from: 'external_fis', to: TABLE_NAMES.LOAN_SUMMARY }, // Balance update

  // === Bank Feedback Loops ===
  { from: 'external_bank', to: TABLE_NAMES.NACHA_TRANS },
  { from: 'external_bank', to: TABLE_NAMES.WIRE_TRANS },

  // === Rollover Flow ===
  { from: TABLE_NAMES.LOAN_BILL, to: TABLE_NAMES.ROLLOVER_SUMMARY }, // Last bill triggers
  { from: TABLE_NAMES.LOAN_SUMMARY, to: TABLE_NAMES.ROLLOVER_SUMMARY },
  { from: TABLE_NAMES.ROLLOVER_SUMMARY, to: TABLE_NAMES.LOAN_SUMMARY }, // Extend term
  { from: TABLE_NAMES.ROLLOVER_SUMMARY, to: TABLE_NAMES.LOAN_CAP_AND_ROLL }, // Rollover to other
  { from: TABLE_NAMES.ROLLOVER_SUMMARY, to: TABLE_NAMES.ACCOUNTING_REQ },

  // === Interest Capitalization Flow ===
  { from: TABLE_NAMES.LOAN_BILL, to: TABLE_NAMES.LOAN_CAP_AND_ROLL }, // Overdue triggers
  { from: TABLE_NAMES.LOAN_CAP_AND_ROLL, to: TABLE_NAMES.LOAN_TRANS_FINAL_QUEUE },
  { from: TABLE_NAMES.LOAN_CAP_AND_ROLL, to: TABLE_NAMES.ACCOUNTING_REQ },
];

export const GRID_COLS = 6;
export const GRID_ROWS = 5;
