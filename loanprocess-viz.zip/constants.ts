import { NodeType, NodeConfig, TABLE_NAMES } from './types';

export const NODES: NodeConfig[] = [
  // --- Row 0: Entities (The "Truth") ---
  { id: 'user', label: 'User / Admin', type: NodeType.USER, row: 0, col: 0 },
  { id: TABLE_NAMES.LOAN_PACKAGE_SUMMARY, label: 'loan_package_summary', type: NodeType.DB_TABLE, row: 0, col: 2 },
  { id: TABLE_NAMES.LOAN_SUMMARY, label: 'loan_summary', type: NodeType.DB_TABLE, row: 0, col: 3 },
  { id: TABLE_NAMES.LOAN_PAYMENT_RULE, label: 'loan_payment_rule', type: NodeType.DB_TABLE, row: 0, col: 4 },

  // --- Row 1: Requests (Inputs) ---
  { id: TABLE_NAMES.LOAN_DRAW_REQUEST, label: 'loan_draw_request', type: NodeType.DB_TABLE, row: 1, col: 1 },
  { id: TABLE_NAMES.LOAN_PAYMENT_REQUEST, label: 'loan_payment_request', type: NodeType.DB_TABLE, row: 1, col: 3 },

  // --- Row 2: Queue Processing ---
  { id: TABLE_NAMES.LOAN_TRANS_QUEUE, label: 'loan_transaction_queue', type: NodeType.DB_TABLE, row: 2, col: 2 },
  { id: 'job_queue_processor', label: 'Queue Processor Job', type: NodeType.PROCESS, row: 2, col: 3 },
  { id: TABLE_NAMES.LOAN_TRANS_FINAL_QUEUE, label: 'loan_transaction_final_queue', type: NodeType.DB_TABLE, row: 2, col: 4 },

  // --- Row 3: Downstream Connectors ---
  { id: TABLE_NAMES.ACCOUNTING_REQ, label: 'accounting_request', type: NodeType.DB_TABLE, row: 3, col: 3 },
  { id: TABLE_NAMES.NACHA_TRANS, label: 'nacha_transaction', type: NodeType.DB_TABLE, row: 3, col: 1 },
  { id: TABLE_NAMES.WIRE_TRANS, label: 'wire_transaction', type: NodeType.DB_TABLE, row: 3, col: 5 },

  // --- Row 4: External Systems ---
  { id: 'external_fis', label: 'FIS System (GL)', type: NodeType.EXTERNAL, row: 4, col: 3 },
  { id: 'external_bank', label: 'Bank (ACH/Wire)', type: NodeType.EXTERNAL, row: 4, col: 1 },
  
  // Feedback Loops
  { id: TABLE_NAMES.LOAN_BILL, label: 'loan_bill', type: NodeType.DB_TABLE, row: 4, col: 4 },
];

export const CONNECTIONS = [
  // Creation Flows
  { from: 'user', to: TABLE_NAMES.LOAN_PACKAGE_SUMMARY },
  { from: TABLE_NAMES.LOAN_PACKAGE_SUMMARY, to: TABLE_NAMES.LOAN_SUMMARY },
  { from: 'user', to: TABLE_NAMES.LOAN_DRAW_REQUEST },
  { from: 'user', to: TABLE_NAMES.LOAN_PAYMENT_RULE },
  
  // Request Processing
  { from: TABLE_NAMES.LOAN_DRAW_REQUEST, to: TABLE_NAMES.LOAN_TRANS_QUEUE },
  { from: TABLE_NAMES.LOAN_PAYMENT_RULE, to: TABLE_NAMES.LOAN_PAYMENT_REQUEST },
  { from: TABLE_NAMES.LOAN_PAYMENT_REQUEST, to: TABLE_NAMES.LOAN_TRANS_QUEUE },
  
  // Queue Logic
  { from: TABLE_NAMES.LOAN_TRANS_QUEUE, to: 'job_queue_processor' },
  { from: 'job_queue_processor', to: TABLE_NAMES.LOAN_TRANS_QUEUE }, // processing loop visual
  { from: TABLE_NAMES.LOAN_TRANS_QUEUE, to: TABLE_NAMES.LOAN_TRANS_FINAL_QUEUE },
  
  // Downstream
  { from: TABLE_NAMES.LOAN_TRANS_FINAL_QUEUE, to: TABLE_NAMES.ACCOUNTING_REQ },
  { from: TABLE_NAMES.LOAN_TRANS_FINAL_QUEUE, to: TABLE_NAMES.NACHA_TRANS },
  { from: TABLE_NAMES.LOAN_TRANS_FINAL_QUEUE, to: TABLE_NAMES.WIRE_TRANS },
  
  // External
  { from: TABLE_NAMES.ACCOUNTING_REQ, to: 'external_fis' },
  { from: TABLE_NAMES.NACHA_TRANS, to: 'external_bank' },
  { from: TABLE_NAMES.WIRE_TRANS, to: 'external_bank' },
  
  // Feedback
  { from: 'external_fis', to: TABLE_NAMES.LOAN_BILL },
];

export const GRID_COLS = 6;
export const GRID_ROWS = 5;
