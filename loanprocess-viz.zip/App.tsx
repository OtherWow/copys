import React from 'react';
import { useSimulation } from './hooks/useSimulation';
import FlowMap from './components/FlowMap';
import ControlPanel from './components/ControlPanel';

const App = () => {
  const { state, activePackets, actions } = useSimulation();

  return (
    <div className="flex flex-col h-screen bg-slate-950 text-slate-200 font-sans overflow-hidden">
      {/* Top Controls */}
      <ControlPanel actions={actions} isProcessing={state.isProcessing} />

      {/* Main Visualization Area */}
      <div className="flex-1 relative w-full h-full bg-slate-900 overflow-hidden">
        {/* Background Grid Pattern */}
        <div className="absolute inset-0 opacity-10" 
             style={{ 
               backgroundImage: 'radial-gradient(#475569 1px, transparent 1px)', 
               backgroundSize: '40px 40px' 
             }}>
        </div>

        <div className="relative w-full h-full flex flex-col">
          <div className="absolute top-4 left-6 z-10">
            <h2 className="text-slate-400 text-sm font-bold uppercase tracking-widest flex items-center gap-3">
              <span className="relative flex h-3 w-3">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-sky-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-3 w-3 bg-sky-500"></span>
              </span>
              System Architecture & Data Flow Visualization
            </h2>
            <p className="text-slate-600 text-xs mt-1 font-mono">Real-time simulation of banking transaction architecture</p>
          </div>
          
          <div className="flex-1 p-8">
             <FlowMap activePackets={activePackets} />
          </div>
        </div>
      </div>
    </div>
  );
};

export default App;