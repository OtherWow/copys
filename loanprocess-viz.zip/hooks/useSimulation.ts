import { useState, useCallback, useRef } from 'react';
import { SimulationState, TABLE_NAMES, DataPacket, LogEntry, TableRow } from '../types';
import { v4 as uuidv4 } from 'uuid';

const INITIAL_STATE: SimulationState = {
  tables: Object.values(TABLE_NAMES).reduce((acc, name) => ({ ...acc, [name]: [] }), {} as Record<string, TableRow[]>),
  logs: [],
  isProcessing: false,
};

export const useSimulation = () => {
  const [state, setState] = useState<SimulationState>(INITIAL_STATE);
  const [activePackets, setActivePackets] = useState<DataPacket[]>([]);
  
  const stateRef = useRef(state);
  stateRef.current = state;

  const addLog = (message: string, type: LogEntry['type'] = 'info') => {
    const entry: LogEntry = {
      id: uuidv4(),
      timestamp: new Date().toLocaleTimeString('zh-CN'),
      message,
      type,
    };
    setState(prev => ({ ...prev, logs: [entry, ...prev.logs] }));
  };

  const resetSimulation = () => {
    setState(INITIAL_STATE);
    setActivePackets([]);
    addLog('系统已重置', 'info');
  };

  const insertRecord = (tableName: string, record: any) => {
    const newRow = { id: uuidv4().slice(0, 8), ...record, created_at: new Date().toISOString() };
    setState(prev => ({
      ...prev,
      tables: {
        ...prev.tables,
        [tableName]: [newRow, ...prev.tables[tableName]],
      },
    }));
    addLog(`写入表 [${tableName}] ID: ${newRow.id}`, 'success');
    return newRow;
  };

  const updateRecord = (tableName: string, recordId: string, updates: any) => {
     setState(prev => ({
      ...prev,
      tables: {
        ...prev.tables,
        [tableName]: prev.tables[tableName].map(row => row.id === recordId ? { ...row, ...updates } : row),
      },
    }));
    addLog(`更新表 [${tableName}] ID: ${recordId} 状态变更`, 'info');
  };

  // Slower animation (2500ms) for clarity
  const sendPacket = (from: string, to: string, label: string, color: string = 'bg-blue-500', duration: number = 2500) => {
    const id = uuidv4();
    setActivePackets(prev => [...prev, { id, from, to, label, color }]);
    
    setTimeout(() => {
      setActivePackets(prev => prev.filter(p => p.id !== id));
    }, duration);

    return new Promise(resolve => setTimeout(resolve, duration * 0.9)); // Wait 90% of animation to chain smoothly
  };

  // --- SCENARIO 1: Create Line ---
  const createLine = async () => {
    if (state.isProcessing) return;
    setState(prev => ({ ...prev, isProcessing: true }));
    addLog('开始创建 Line 额度流程...', 'process');

    // 1. User -> Package
    await sendPacket('user', TABLE_NAMES.LOAN_PACKAGE_SUMMARY, '创建 Line', 'bg-green-500');
    const pkg = insertRecord(TABLE_NAMES.LOAN_PACKAGE_SUMMARY, { 
      client_name: 'Acme Corp', 
      credit_limit: 1000000, 
      status: 'ACTIVE' 
    });

    // 2. Package -> Loan Summary (Variable)
    await sendPacket(TABLE_NAMES.LOAN_PACKAGE_SUMMARY, TABLE_NAMES.LOAN_SUMMARY, '初始化 Variable Loan', 'bg-green-500');
    insertRecord(TABLE_NAMES.LOAN_SUMMARY, {
      package_id: pkg.id,
      loan_type: 'VARIABLE',
      balance: 0,
      status: 'OPEN'
    });

    addLog('Line 创建完成', 'success');
    setState(prev => ({ ...prev, isProcessing: false }));
  };

  // --- SCENARIO 2: Draw (Variable or Fixed) ---
  const performDraw = async (type: 'VARIABLE' | 'FIXED_TERM', amount: number) => {
    if (state.isProcessing) return;
    setState(prev => ({ ...prev, isProcessing: true }));
    const typeLabel = type === 'VARIABLE' ? 'Variable' : 'Fixed';
    addLog(`开始 ${typeLabel} Draw 流程 (金额: ${amount})...`, 'process');

    // 1. User -> Draw Request
    await sendPacket('user', TABLE_NAMES.LOAN_DRAW_REQUEST, '发起 Draw 请求', 'bg-blue-500');
    const drawReq = insertRecord(TABLE_NAMES.LOAN_DRAW_REQUEST, {
      amount,
      draw_type: type === 'VARIABLE' ? 'ACH' : 'WIRE',
      status: 'PENDING'
    });

    // 2. Approval
    await new Promise(r => setTimeout(r, 800));
    updateRecord(TABLE_NAMES.LOAN_DRAW_REQUEST, drawReq.id, { status: 'APPROVED' });
    addLog('Draw 请求已审批', 'info');
    
    // 3. Request -> Queue
    await sendPacket(TABLE_NAMES.LOAN_DRAW_REQUEST, TABLE_NAMES.LOAN_TRANS_QUEUE, '写入交易队列', 'bg-blue-500');
    const transQ = insertRecord(TABLE_NAMES.LOAN_TRANS_QUEUE, {
      source_id: drawReq.id,
      source_table: 'loan_draw_request',
      amount,
      status: 'PENDING'
    });

    // 4. Update Loan Summary
    if (type === 'VARIABLE') {
       const varLoan = stateRef.current.tables[TABLE_NAMES.LOAN_SUMMARY].find(l => l.loan_type === 'VARIABLE');
       if (varLoan) {
         await sendPacket(TABLE_NAMES.LOAN_TRANS_QUEUE, TABLE_NAMES.LOAN_SUMMARY, '更新余额', 'bg-yellow-500');
         updateRecord(TABLE_NAMES.LOAN_SUMMARY, varLoan.id, { balance: varLoan.balance + amount });
       }
    } else {
      await sendPacket(TABLE_NAMES.LOAN_TRANS_QUEUE, TABLE_NAMES.LOAN_SUMMARY, '创建 Fixed Loan', 'bg-yellow-500');
      insertRecord(TABLE_NAMES.LOAN_SUMMARY, {
        loan_type: 'FIXED',
        balance: amount,
        term: '30_DAYS',
        status: 'OPEN'
      });
    }

    // 5. Job Processing
    await sendPacket('job_queue_processor', TABLE_NAMES.LOAN_TRANS_QUEUE, 'Job 处理', 'bg-purple-500');
    updateRecord(TABLE_NAMES.LOAN_TRANS_QUEUE, transQ.id, { status: 'FINALIZED' });
    
    await sendPacket(TABLE_NAMES.LOAN_TRANS_QUEUE, TABLE_NAMES.LOAN_TRANS_FINAL_QUEUE, '最终交易确认', 'bg-purple-500');
    const finalQ = insertRecord(TABLE_NAMES.LOAN_TRANS_FINAL_QUEUE, {
      original_id: transQ.id,
      amount,
      accounting_status: 'INIT'
    });

    // 6. Downstream
    await processDownstream(finalQ, type === 'VARIABLE' ? 'ACH' : 'WIRE');

    setState(prev => ({ ...prev, isProcessing: false }));
  };

  // --- Shared Downstream Logic ---
  const processDownstream = async (finalQRow: any, method: 'ACH' | 'WIRE') => {
    // Accounting
    sendPacket(TABLE_NAMES.LOAN_TRANS_FINAL_QUEUE, TABLE_NAMES.ACCOUNTING_REQ, '请求记账 (FIS)', 'bg-orange-500')
      .then(async () => {
        const accReq = insertRecord(TABLE_NAMES.ACCOUNTING_REQ, {
          trans_id: finalQRow.id,
          status: 'PENDING'
        });
        updateRecord(TABLE_NAMES.LOAN_TRANS_FINAL_QUEUE, finalQRow.id, { accounting_status: 'PREPARE_SYNC' });
        
        // Call FIS
        await sendPacket(TABLE_NAMES.ACCOUNTING_REQ, 'external_fis', '调用 FIS 接口', 'bg-red-500');
        updateRecord(TABLE_NAMES.ACCOUNTING_REQ, accReq.id, { status: 'SUCCESS' });
        
        // FIS Callback
        await sendPacket('external_fis', TABLE_NAMES.LOAN_BILL, '生成账单 (回写)', 'bg-red-500', 1500);
        insertRecord(TABLE_NAMES.LOAN_BILL, {
          loan_id: '...',
          amount_due: 500,
          due_date: '2023-12-01'
        });
      });

    // Bank
    if (method === 'ACH') {
      await sendPacket(TABLE_NAMES.LOAN_TRANS_FINAL_QUEUE, TABLE_NAMES.NACHA_TRANS, '生成 NACHA 文件', 'bg-cyan-500');
      const nacha = insertRecord(TABLE_NAMES.NACHA_TRANS, { trans_id: finalQRow.id, status: 'GENERATED' });
      
      await sendPacket(TABLE_NAMES.NACHA_TRANS, 'external_bank', '上传银行 (ACH)', 'bg-cyan-500');
      updateRecord(TABLE_NAMES.NACHA_TRANS, nacha.id, { status: 'SENT' });
    } else {
      await sendPacket(TABLE_NAMES.LOAN_TRANS_FINAL_QUEUE, TABLE_NAMES.WIRE_TRANS, '生成 Wire 文件', 'bg-cyan-500');
      const wire = insertRecord(TABLE_NAMES.WIRE_TRANS, { trans_id: finalQRow.id, status: 'GENERATED' });

      await sendPacket(TABLE_NAMES.WIRE_TRANS, 'external_bank', '发送 Wire 指令', 'bg-cyan-500');
      updateRecord(TABLE_NAMES.WIRE_TRANS, wire.id, { status: 'SENT' });
    }
  };

  // --- SCENARIO 3: Create Payment Rule ---
  const createPaymentRule = async () => {
    if (state.isProcessing) return;
    setState(prev => ({ ...prev, isProcessing: true }));
    addLog('开始创建还款规则 (Payment Rule)...', 'process');

    // 1. User -> Rule
    await sendPacket('user', TABLE_NAMES.LOAN_PAYMENT_RULE, '设置规则', 'bg-indigo-500');
    const rule = insertRecord(TABLE_NAMES.LOAN_PAYMENT_RULE, {
      type: 'INTEREST_DUE_ONLY',
      frequency: 'MONTHLY'
    });

    // 2. Job Trigger
    addLog('Job: 根据规则生成 Payment Request...', 'process');
    await new Promise(r => setTimeout(r, 1000));
    
    await sendPacket(TABLE_NAMES.LOAN_PAYMENT_RULE, TABLE_NAMES.LOAN_PAYMENT_REQUEST, '生成还款请求', 'bg-indigo-500');
    const payReq = insertRecord(TABLE_NAMES.LOAN_PAYMENT_REQUEST, {
      rule_id: rule.id,
      amount: 1200, 
      status: 'PENDING'
    });

    // 3. Payment Request -> Queue
    await sendPacket(TABLE_NAMES.LOAN_PAYMENT_REQUEST, TABLE_NAMES.LOAN_TRANS_QUEUE, '写入交易队列', 'bg-indigo-500');
    const transQ = insertRecord(TABLE_NAMES.LOAN_TRANS_QUEUE, {
      source_id: payReq.id,
      source_table: 'loan_payment_request',
      amount: 1200,
      type: 'PAYMENT',
      status: 'PENDING'
    });
    
    updateRecord(TABLE_NAMES.LOAN_PAYMENT_REQUEST, payReq.id, { status: 'PROCESSED' });

    // 4. To Final Queue
    await sendPacket('job_queue_processor', TABLE_NAMES.LOAN_TRANS_QUEUE, 'Job 处理', 'bg-purple-500');
    updateRecord(TABLE_NAMES.LOAN_TRANS_QUEUE, transQ.id, { status: 'FINALIZED' });

    await sendPacket(TABLE_NAMES.LOAN_TRANS_QUEUE, TABLE_NAMES.LOAN_TRANS_FINAL_QUEUE, '最终交易确认', 'bg-purple-500');
    const finalQ = insertRecord(TABLE_NAMES.LOAN_TRANS_FINAL_QUEUE, {
      original_id: transQ.id,
      amount: 1200,
      type: 'PAYMENT',
      accounting_status: 'INIT'
    });

    // 5. Downstream
    await processDownstream(finalQ, 'ACH');

    setState(prev => ({ ...prev, isProcessing: false }));
  };

  return {
    state,
    activePackets,
    actions: {
      createLine,
      performDraw,
      createPaymentRule,
      resetSimulation
    }
  };
};