import React from 'react';
import { Play, CreditCard, DollarSign, CalendarClock, RotateCcw } from 'lucide-react';

interface ControlPanelProps {
  actions: {
    createLine: () => void;
    performDraw: (type: 'VARIABLE' | 'FIXED_TERM', amount: number) => void;
    createPaymentRule: () => void;
    resetSimulation: () => void;
  };
  isProcessing: boolean;
}

const ControlPanel: React.FC<ControlPanelProps> = ({ actions, isProcessing }) => {
  return (
    <div className="sticky top-0 z-50 flex flex-wrap gap-3 p-4 bg-slate-800 border-b border-slate-700 shadow-md">
      <div className="flex items-center gap-2 mr-2">
        <h2 className="text-sm font-bold text-slate-400 uppercase tracking-wider">业务场景控制</h2>
      </div>

      <button
        onClick={actions.createLine}
        disabled={isProcessing}
        className="flex items-center gap-2 px-3 py-2 bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 disabled:cursor-not-allowed text-white rounded-md text-xs font-medium transition-colors"
      >
        <Play className="w-3 h-3" />
        1. 创建 Line 额度
      </button>

      <button
        onClick={() => actions.performDraw('VARIABLE', 5000)}
        disabled={isProcessing}
        className="flex items-center gap-2 px-3 py-2 bg-blue-600 hover:bg-blue-500 disabled:opacity-50 disabled:cursor-not-allowed text-white rounded-md text-xs font-medium transition-colors"
      >
        <DollarSign className="w-3 h-3" />
        2. Variable Draw (ACH)
      </button>

      <button
        onClick={() => actions.performDraw('FIXED_TERM', 50000)}
        disabled={isProcessing}
        className="flex items-center gap-2 px-3 py-2 bg-cyan-600 hover:bg-cyan-500 disabled:opacity-50 disabled:cursor-not-allowed text-white rounded-md text-xs font-medium transition-colors"
      >
        <DollarSign className="w-3 h-3" />
        2. Fixed Draw (Wire)
      </button>

      <button
        onClick={actions.createPaymentRule}
        disabled={isProcessing}
        className="flex items-center gap-2 px-3 py-2 bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 disabled:cursor-not-allowed text-white rounded-md text-xs font-medium transition-colors"
      >
        <CalendarClock className="w-3 h-3" />
        3. Payment Rule 还款
      </button>

      <div className="flex-1"></div>

      <button
        onClick={actions.resetSimulation}
        disabled={isProcessing}
        className="flex items-center gap-2 px-3 py-2 bg-slate-700 hover:bg-slate-600 text-slate-300 border border-slate-600 rounded-md text-xs font-medium transition-colors"
      >
        <RotateCcw className="w-3 h-3" />
        清空重置
      </button>
      
      {isProcessing && (
        <div className="flex items-center text-amber-400 text-xs animate-pulse font-mono">
          处理中...
        </div>
      )}
    </div>
  );
};

export default ControlPanel;