import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Database, User, Server, Globe, Activity, FileText, Cpu, ArrowRightLeft } from 'lucide-react';
import { NodeConfig, NodeType, DataPacket } from '../types';
import { NODES, GRID_COLS, GRID_ROWS, CONNECTIONS } from '../constants';
import clsx from 'clsx';

interface FlowMapProps {
  activePackets: DataPacket[];
}

const NodeIcon = ({ type, label }: { type: NodeType, label: string }) => {
  // Custom icons based on label content or type for better visual distinction
  if (label.includes('User')) return <User className="w-8 h-8 text-white" />;
  if (label.includes('Queue Processor')) return <Cpu className="w-8 h-8 text-amber-200" />;
  if (label.includes('FIS')) return <Server className="w-8 h-8 text-red-200" />;
  if (label.includes('Bank')) return <Globe className="w-8 h-8 text-cyan-200" />;
  if (label.includes('rule')) return <FileText className="w-8 h-8 text-indigo-200" />;
  if (label.includes('queue')) return <ArrowRightLeft className="w-8 h-8 text-purple-200" />;
  
  switch (type) {
    case NodeType.DB_TABLE: return <Database className="w-8 h-8 text-blue-200" />;
    case NodeType.PROCESS: return <Activity className="w-8 h-8 text-yellow-200" />;
    default: return <Server className="w-8 h-8" />;
  }
};

const FlowMap: React.FC<FlowMapProps> = ({ activePackets }) => {
  
  // Calculate center percentage positions for nodes (for lines)
  const getNodeCenter = (node: NodeConfig) => {
    const x = ((node.col + 0.5) / GRID_COLS) * 100;
    const y = ((node.row + 0.5) / GRID_ROWS) * 100;
    return { x, y };
  };

  // Helper to get raw coordinates for animation (for packets)
  const getNodePositionStyle = (id: string) => {
    const node = NODES.find(n => n.id === id);
    if (!node) return { top: '50%', left: '50%' };
    return { 
      top: `${((node.row + 0.5) / GRID_ROWS) * 100}%`, 
      left: `${((node.col + 0.5) / GRID_COLS) * 100}%` 
    };
  };

  return (
    <div className="relative w-full h-full border border-slate-800/50 rounded-3xl bg-slate-900/40 backdrop-blur-sm shadow-2xl overflow-visible">
      
      {/* 1. SVG Layer for Lines (Pipes) */}
      <svg className="absolute inset-0 w-full h-full pointer-events-none z-0">
        <defs>
          <marker
            id="arrowhead"
            markerWidth="10"
            markerHeight="7"
            refX="9"
            refY="3.5"
            orient="auto"
          >
            <polygon points="0 0, 10 3.5, 0 7" fill="#64748b" />
          </marker>
        </defs>
        {CONNECTIONS.map((conn, idx) => {
          const startNode = NODES.find(n => n.id === conn.from);
          const endNode = NODES.find(n => n.id === conn.to);
          if (!startNode || !endNode) return null;

          const start = getNodeCenter(startNode);
          const end = getNodeCenter(endNode);

          return (
            <g key={idx}>
              {/* Background thick line for contrast */}
              <line
                x1={`${start.x}%`}
                y1={`${start.y}%`}
                x2={`${end.x}%`}
                y2={`${end.y}%`}
                stroke="#0f172a"
                strokeWidth="4"
              />
              {/* Visible Line */}
              <line
                x1={`${start.x}%`}
                y1={`${start.y}%`}
                x2={`${end.x}%`}
                y2={`${end.y}%`}
                stroke="#475569"
                strokeWidth="2"
                strokeDasharray="5,5"
                markerEnd="url(#arrowhead)"
                opacity="0.6"
              />
            </g>
          );
        })}
      </svg>

      {/* 2. Grid for Nodes */}
      <div 
        className="absolute inset-0 grid gap-6 p-12 pointer-events-none z-10"
        style={{
          gridTemplateColumns: `repeat(${GRID_COLS}, 1fr)`,
          gridTemplateRows: `repeat(${GRID_ROWS}, 1fr)`
        }}
      >
        {NODES.map((node) => {
          // Check if this node is currently active (being targeted by a packet)
          const isActive = activePackets.some(p => p.to === node.id || p.from === node.id);
          
          return (
            <div 
              key={node.id} 
              className="relative pointer-events-auto flex items-center justify-center"
              style={{ gridColumnStart: node.col + 1, gridRowStart: node.row + 1 }}
            >
              <div className={clsx(
                "relative flex flex-col items-center justify-center w-full max-w-[140px] aspect-square rounded-2xl border transition-all duration-500",
                "shadow-[0_0_20px_rgba(0,0,0,0.3)] backdrop-blur-md",
                isActive ? "scale-105 border-sky-500/50 shadow-[0_0_30px_rgba(14,165,233,0.3)]" : "border-slate-700/50 bg-slate-800/60",
                node.type === NodeType.USER ? "bg-indigo-900/30" :
                node.type === NodeType.EXTERNAL ? "bg-red-900/10" :
                ""
              )}>
                
                {/* Ping Effect for Active Nodes */}
                {isActive && (
                  <span className="absolute inset-0 rounded-2xl animate-ping border border-sky-400/30 opacity-75 pointer-events-none"></span>
                )}

                <div className={clsx(
                  "mb-3 p-3 rounded-xl transition-colors duration-500",
                  isActive ? "bg-slate-700" : "bg-slate-800",
                  node.type === NodeType.USER ? "text-indigo-400" :
                  node.type === NodeType.DB_TABLE ? "text-blue-400" :
                  node.type === NodeType.PROCESS ? "text-amber-400" :
                  "text-red-400"
                )}>
                  <NodeIcon type={node.type} label={node.label} />
                </div>
                
                <span className="text-[11px] font-bold font-mono text-center text-slate-300 leading-tight w-full px-2 break-words uppercase tracking-tight">
                  {node.label.replace(/_/g, ' ')}
                </span>
                
                {/* Type Badge */}
                <div className="absolute -top-3 px-2 py-0.5 rounded-full bg-slate-950 border border-slate-700 text-[9px] font-bold text-slate-500 uppercase tracking-wider">
                  {node.type === NodeType.DB_TABLE ? 'TABLE' : node.type}
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* 3. Animation Layer (Packets) */}
      <div className="absolute inset-0 pointer-events-none z-20">
        <AnimatePresence>
          {activePackets.map((packet) => {
            const start = getNodePositionStyle(packet.from);
            const end = getNodePositionStyle(packet.to);

            return (
              <motion.div
                key={packet.id}
                initial={{ top: start.top, left: start.left, opacity: 0, scale: 0.5 }}
                animate={{ 
                  top: end.top, 
                  left: end.left, 
                  opacity: 1, 
                  scale: 1,
                  transition: { duration: 2.2, ease: "easeInOut" } 
                }}
                exit={{ opacity: 0, scale: 0 }}
                className="absolute flex items-center justify-center w-0 h-0"
              >
                <div className="relative flex items-center justify-center -translate-x-1/2 -translate-y-1/2">
                  {/* Glowing Core */}
                  <div className={clsx(
                    "w-6 h-6 rounded-full shadow-[0_0_25px_rgba(255,255,255,0.6)] z-10 border-2 border-white", 
                    packet.color
                  )}></div>
                  
                  {/* Trail effect */}
                  <div className={clsx("absolute w-12 h-12 rounded-full opacity-30 animate-ping", packet.color)}></div>

                  {/* Label */}
                  <div className="absolute -top-8 whitespace-nowrap bg-slate-900/90 px-3 py-1 rounded-md text-white font-mono text-xs border border-slate-700 shadow-xl z-20">
                    {packet.label}
                    {/* Tiny triangle pointing down */}
                    <div className="absolute left-1/2 -bottom-1 -translate-x-1/2 w-2 h-2 bg-slate-900 border-r border-b border-slate-700 rotate-45"></div>
                  </div>
                </div>
              </motion.div>
            );
          })}
        </AnimatePresence>
      </div>
      
      {/* Key Legend */}
      <div className="absolute bottom-6 right-6 flex flex-col gap-2 bg-slate-900/90 p-4 rounded-xl border border-slate-800 shadow-xl backdrop-blur-md">
         <h4 className="text-xs font-bold text-slate-500 uppercase tracking-widest mb-1">Flow Legend</h4>
         <div className="flex items-center gap-3">
            <span className="flex w-3 h-3 rounded-full bg-blue-500 border border-white/20"></span>
            <span className="text-xs text-slate-300">Draw Request</span>
         </div>
         <div className="flex items-center gap-3">
            <span className="flex w-3 h-3 rounded-full bg-indigo-500 border border-white/20"></span>
            <span className="text-xs text-slate-300">Payment Process</span>
         </div>
         <div className="flex items-center gap-3">
            <span className="flex w-3 h-3 rounded-full bg-cyan-500 border border-white/20"></span>
            <span className="text-xs text-slate-300">Bank / ACH</span>
         </div>
         <div className="flex items-center gap-3">
            <span className="flex w-3 h-3 rounded-full bg-red-500 border border-white/20"></span>
            <span className="text-xs text-slate-300">Accounting (GL)</span>
         </div>
      </div>

    </div>
  );
};

export default FlowMap;