export enum NodeType {
  USER = 'USER',
  DB_TABLE = 'DB_TABLE',
  PROCESS = 'PROCESS',
  EXTERNAL = 'EXTERNAL',
}

export interface NodeConfig {
  id: string;
  label: string;
  type: NodeType;
  row: number; // Grid row position
  col: number; // Grid col position
  description?: string;
}

export interface DataPacket {
  id: string;
  from: string;
  to: string;
  label: string;
  color: string;
}

export interface LogEntry {
  id: string;
  timestamp: string;
  message: string;
  type: 'info' | 'success' | 'error' | 'process';
}

export interface TableRow {
  id: string;
  [key: string]: any;
}

export interface SimulationState {
  tables: Record<string, TableRow[]>;
  logs: LogEntry[];
  isProcessing: boolean;
}

export const TABLE_NAMES = {
  LOAN_PACKAGE_SUMMARY: 'loan_package_summary',
  LOAN_SUMMARY: 'loan_summary',
  LOAN_DRAW_REQUEST: 'loan_draw_request',
  LOAN_PAYMENT_RULE: 'loan_payment_rule',
  LOAN_PAYMENT_REQUEST: 'loan_payment_request',
  LOAN_TRANS_QUEUE: 'loan_transaction_queue',
  LOAN_TRANS_FINAL_QUEUE: 'loan_transaction_final_queue',
  ACCOUNTING_REQ: 'accounting_request',
  NACHA_TRANS: 'nacha_transaction',
  WIRE_TRANS: 'wire_transaction',
  LOAN_BILL: 'loan_bill',
};